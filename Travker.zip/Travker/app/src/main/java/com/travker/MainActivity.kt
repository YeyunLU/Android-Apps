package com.travker

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Vibrator
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v4.content.ContextCompat.getSystemService
import android.support.v4.content.ContextCompat.startActivity
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ListView
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.add_notes.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        checkPermissions()
        listViewSetup()
    }

    override fun onRestart() {
        super.onRestart()
        listViewSetup()
    }

    fun newDirary(view: View){
        buttonVibe()
        val intent = Intent(this, NewDiary::class.java)
        startActivity(intent)
    }

    private fun buttonVibe(){
        val vibratorService = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vibratorService.vibrate(100)
    }

    private fun listViewSetup(){
        var db = DataBase()
        var arrDiary: ArrayList<Diary> = ArrayList()

        db.connectFirebaseRTDB()
        FirebaseApp.initializeApp(this)

        db.getDiaryTable().addValueEventListener(object:ValueEventListener{
            override fun onDataChange(data: DataSnapshot) {
                for(child in data.children){
                    arrDiary.add(child.getValue(Diary::class.java)!!)
                }

                Log.d("Main", arrDiary.size.toString())
                lvMain.adapter = MainAdapter(applicationContext, arrDiary)
                lvMain.setOnItemClickListener { _, _, position, _ ->
                    Log.d("Main", arrDiary[position].name)
                    val intent = Intent(applicationContext, HistoryDiary::class.java)
                    intent.putExtra("id",arrDiary[position].id)
                    intent.putExtra("date",arrDiary[position].date)
                    intent.putExtra("name",arrDiary[position].name)
                    startActivity(intent)
                }
            }
            override fun onCancelled(databaseError: DatabaseError) {
                Log.e("Get Data from Firebase", "Can not retrive data!")
            }
        })
    }

    private fun checkPermissions(){
        val permissions = arrayOf(
            android.Manifest.permission.RECORD_AUDIO,
            android.Manifest.permission.READ_EXTERNAL_STORAGE,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        )

        for(permission in permissions){
            if(ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this, permissions,101)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            101 -> {
                if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission has been denied by user", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

}