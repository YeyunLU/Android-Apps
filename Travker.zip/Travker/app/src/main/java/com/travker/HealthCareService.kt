package com.travker

import android.app.Service
import android.content.Context
import android.hardware.*
import android.util.Log
import android.content.Intent
import android.os.Binder
import android.os.IBinder



class HealthCareService: Service(), SensorEventListener {
    private lateinit var sensorManager:SensorManager
    private lateinit var stepCounter:Sensor
    //private lateinit var temperatureSensor: Sensor
    private val binder = LocalBinder()
    private var stepCounts = 0

    fun getSteps():Int{
        return stepCounts
    }

    inner class LocalBinder : Binder() {
        fun getService():HealthCareService = this@HealthCareService
    }

    override fun onCreate() {
        super.onCreate()
        sensorManager = this.getSystemService(Context.SENSOR_SERVICE) as SensorManager

        if(sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null) {
            stepCounter = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
            sensorManager!!.registerListener(this, stepCounter, SensorManager.SENSOR_DELAY_NORMAL)
            stepCounts = 0
        }

//        if(sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE) != null){
//            temperatureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)
//            sensorManager!!.registerListener(this, temperatureSensor, SensorManager.SENSOR_DELAY_NORMAL)
//        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("HealthCare Service", "Start")
        return Service.START_STICKY
    }

    override fun onBind(intent: Intent): IBinder {
        return binder
    }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this, stepCounter)
        Log.d("HealthCare Service", "Destory")
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}

    override fun onSensorChanged(event: SensorEvent) {
        stepCounts++
        Log.d("HealthCare Service", "Step changed: " + stepCounts)
    }
}