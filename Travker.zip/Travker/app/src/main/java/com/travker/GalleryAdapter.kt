package com.travker

import android.content.ClipData
import android.content.ClipDescription
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.DragEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.Toast
import android.net.Uri
import android.support.v4.content.ContextCompat.startActivity
import android.widget.GridView




class GalleryAdapter : BaseAdapter {
    private var uriList:ArrayList<Uri>
    private var context: Context

    constructor(context:Context, uriList:ArrayList<Uri>){
        this.context = context
        this.uriList = uriList
    }

    override fun getCount(): Int {
        return uriList.size
    }

    override fun getItem(position: Int): Uri {
        return uriList[position]
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val inflater:LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.gv_gallery,null)

        val ivGallery = view.findViewById(R.id.ivGallery) as ImageView

        val bmOptions = BitmapFactory.Options()
        bmOptions.inJustDecodeBounds = true
        BitmapFactory.decodeStream(context.contentResolver.openInputStream(uriList[position]), null, bmOptions)

        bmOptions.inJustDecodeBounds = false
        bmOptions.inSampleSize = 20

        val bitmap = BitmapFactory.decodeStream(context.contentResolver.openInputStream(uriList[position]), null, bmOptions)
        ivGallery.setImageBitmap(bitmap)

        ivGallery.id = position
        ivGallery.tag = uriList[position]
        ivGallery.setOnLongClickListener{ v: View->
            val dragData = ClipData.newPlainText("","")
            val myShadow = MyDragShadowBuilder(v)

            // Starts the drag
            v.startDrag(
                dragData,   // the data to be dragged
                myShadow,   // the drag shadow builder
                v,       // no need to use local data
                0           // flags (not currently used, set to 0)
            )
        }

        ivGallery.setOnClickListener{
            val intent = Intent(context, FullScreenImage::class.java)
            intent.putExtra("uri", uriList[position].toString())
            context.startActivity(intent)
        }

        val dragListen = View.OnDragListener { v, event ->
            // Handles each of the expected events
            when (event.action) {
                DragEvent.ACTION_DRAG_STARTED -> {
                    // Determines if this View can accept the dragged data
                    if (event.clipDescription.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) {
                        // Invalidate the view to force a redraw in the new tint
                        v.invalidate()

                        // returns true to indicate that the View can accept the dragged data.
                        true
                    } else {
                        // Returns false. DbitmapListng the current drag and drop operation, this View will
                        // not receive events again until ACTION_DRAG_ENDED is sent.
                        false
                    }
                }
                DragEvent.ACTION_DRAG_ENTERED -> {
                    // Applies a green tint to the View. Return true; the return value is ignored.
                    (v as? ImageView)?.setColorFilter(Color.argb(125, 192,192,192))

                    // Invalidate the view to force a redraw in the new tint
                    v.invalidate()
                    true
                }

                DragEvent.ACTION_DRAG_LOCATION ->
                    // Ignore the event
                    true
                DragEvent.ACTION_DRAG_EXITED -> {
                    // Invalidate the view to force a redraw in the new tint
                    v.invalidate()
                    true
                }
                DragEvent.ACTION_DROP -> {
                    // Gets the item containing the dragged data
                    val item = (event.localState as ImageView)
                    Log.d("Photo", item.id.toString() + "  " + v.id)
                    Toast.makeText(context, "Photo order changed.", Toast.LENGTH_LONG).show()

                    val itemUri = item.tag as Uri
                    val vPosition = uriList.indexOf((v as ImageView).tag)
                    uriList.remove(itemUri)
                    uriList.add(vPosition,itemUri)

                    val gv = parent as GridView
                    gv.deferNotifyDataSetChanged()
                    gv.invalidateViews()

                    // Turns off any color tints
                    (v as? ImageView)?.clearColorFilter()

                    // Invalidates the view to force a redraw
                    v.invalidate()

                    // Returns true. DragEvent.getResult() will return true.
                    true
                }

                DragEvent.ACTION_DRAG_ENDED -> {
                    // Turns off any color tinting
                    (v as? ImageView)?.clearColorFilter()

                    // Invalidates the view to force a redraw
                    v.invalidate()

                    // returns true; the value is ignored.
                    true
                }
                else -> {
                    // An unknown action type was received.
                    Log.e("DragDrop Example", "Unknown action type received by OnDragListener.")
                    false
                }
            }
        }

        ivGallery.setOnDragListener(dragListen)
        return view
    }
}

private class MyDragShadowBuilder(v: View) : View.DragShadowBuilder(v) {

    private val shadow = ColorDrawable(Color.LTGRAY)

    // Defines a callback that sends the drag shadow dimensions and touch point back to the
    // system.
    override fun onProvideShadowMetrics(size: Point, touch: Point) {
        // Sets the width of the shadow to half the width of the original View
        val width: Int = view.width / 2

        // Sets the height of the shadow to half the height of the original View
        val height: Int = view.height / 2

        // The drag shadow is a ColorDrawable. This sets its dimensions to be the same as the
        // Canvas that the system will provide. As a result, the drag shadow will fill the
        // Canvas.
        shadow.setBounds(0, 0, width, height)

        // Sets the size parameter's width and height values. These get back to the system
        // through the size parameter.
        size.set(width, height)

        // Sets the touch point's position to be in the middle of the drag shadow
        touch.set(width / 2, height / 2)
    }

    // Defines a callback that draws the drag shadow in a Canvas that the system constructs
    // from the dimensions passed in onProvideShadowMetrics().
    override fun onDrawShadow(canvas: Canvas) {
        // Draws the ColorDrawable in the Canvas passed in from the system.
        shadow.draw(canvas)
    }
}