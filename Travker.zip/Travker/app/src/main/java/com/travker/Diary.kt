package com.travker

import android.graphics.Bitmap

class Diary( var id:String?="",
             var date: String?="",
             var name:String?="",
             var image: String?=""){
}


