package com.travker

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Vibrator
import android.speech.SpeechRecognizer
import android.support.v7.app.AppCompatActivity
import android.view.View
import kotlinx.android.synthetic.main.add_notes.*
import android.view.MotionEvent
import android.widget.Toast


class AddNotes : AppCompatActivity() {
    private lateinit var speechIntent: Intent
    private lateinit var speechRecognizer:SpeechRecognizer


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.add_notes)

        initSpeech()

        val notesContent = intent.getStringExtra("notesContent")
        if(notesContent != "")
            etNotes.setText(notesContent)

    }

    fun saveNotes(view :View){
        buttonVibe()
        Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
        val intent = Intent(this, NewDiary::class.java)
        intent.putExtra("notesContent", etNotes.text.toString())
        setResult(RESULT_OK, intent)
        finish()
    }

    private fun initSpeech(){
        buttonVibe()
        var speech = SpeechToText()
        val checkPermission = speech.checkMicrophonePermission(this)

        if(checkPermission){
            speechIntent = speech.setSpeechIntent()
            speechRecognizer = speech.setSpeechRecognizer(this, etNotes)

            ibVoice.setOnTouchListener(View.OnTouchListener { _, motionEvent ->
                when (motionEvent.action) {
                    MotionEvent.ACTION_UP -> {
                        speechRecognizer.stopListening()
                    }

                    MotionEvent.ACTION_DOWN -> {
                        speechRecognizer.startListening(speechIntent)
                        Toast.makeText(this, R.string.speech_prompt, Toast.LENGTH_SHORT).show()
                    }
                }
                false
            })
        }
        else{
            ibVoice.visibility = View.INVISIBLE
            tvVoice.visibility = View.INVISIBLE
        }
    }

    private fun buttonVibe(){
        val vibratorService = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vibratorService.vibrate(100)
    }
}