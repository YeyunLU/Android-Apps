package com.travker

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.data_base.*
import com.google.firebase.database.DatabaseReference


class DataBase{

    private companion object {
        const val FIREBASE_USERNAME = "yy951026@uw.edu"
        const val FIREBASE_PASSWORD = "19951026Lyy"
    }

    private lateinit var mAuth: FirebaseAuth
    private var diaryTable = FirebaseDatabase.getInstance().getReference("Diaries")
    private var detailsTable = FirebaseDatabase.getInstance().getReference("Details")

    //Connect to the Firebase RealTime DataBase
    fun connectFirebaseRTDB(){
        //Connect to firebase
        mAuth = FirebaseAuth.getInstance()
        mAuth.signInWithEmailAndPassword(FIREBASE_USERNAME, FIREBASE_PASSWORD)
        Log.d("Main", "Connected to Database!")
    }

    fun getDiaryTable():DatabaseReference{
        return diaryTable
    }

    fun getDetailTable():DatabaseReference{
        return detailsTable
    }
}