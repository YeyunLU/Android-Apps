package com.travker

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.os.Binder
import android.os.Bundle
import android.os.IBinder
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.util.Log
import android.widget.Toast
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.*
import com.travker.NewDiary.Companion.mMap
import java.lang.Double.parseDouble

class MapService : Service() {
    private var mLocationManager: LocationManager? = null
    private val binder = LocalBinder()
    companion object {
        private val TAG = "MapService"
        private val LOCATION_INTERVAL = 500 // 0.5 second
        private val LOCATION_DISTANCE = 0.5f // 0.3 meter
        private var first = false
        private val path = ArrayList<LatLng>()
        var stayTime = 0
    }

    var mLocationListeners = arrayOf(LocationListener(LocationManager.PASSIVE_PROVIDER))

    inner class LocalBinder : Binder() {
        fun getService():MapService = this@MapService
    }

    override fun onCreate() {
        super.onCreate()
        first = true
        path.clear()
        initializeLocationManager()
        try {
            mLocationManager!!.requestLocationUpdates(
                LocationManager.PASSIVE_PROVIDER,
                LOCATION_INTERVAL.toLong(),
                LOCATION_DISTANCE,
                mLocationListeners[0]
            )
        } catch (ex: java.lang.SecurityException) {
            Log.i(TAG, "fail to request location update, ignore", ex)
        } catch (ex: IllegalArgumentException) {
            Log.d(TAG, "network provider does not exist, " + ex.message)
        }
    }

    inner class LocationListener(provider: String) : android.location.LocationListener {
        init {
            Log.e(TAG, "LocationListener $provider")
        }
        override fun onLocationChanged(location: Location) {
            stayTime++
            Log.e(TAG, "onLocationChanged: $location")
            val currentLatLng = LatLng(location.latitude, location.longitude)
            NewDiary.polypts.add(currentLatLng.toString())
            path.add(currentLatLng)
            val options = PolylineOptions()
            options.color(Color.RED)
                .width(10f)
            var iterator =  path.iterator()
            while(iterator.hasNext()) {
                options.add(iterator.next())
            }
            mMap!!.addPolyline(options)
            if(first){
                mMap.addMarker(MarkerOptions()
                    .position(currentLatLng)
                    .icon( bitmapDescriptorFromVector(this@MapService, R.drawable.star,15))
                    // draw a star for start point
                    .title("Start"))

                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15f))
                first = false
            }
            if(stayTime==10){
                stayTime = 0
                mMap.addMarker(MarkerOptions()
                    .position(currentLatLng)
                    .icon( bitmapDescriptorFromVector(this@MapService, R.drawable.paw,20))
                    // draw a star for start point
                    .title("Spot"))
            }
        }
        override fun onProviderDisabled(provider: String) {
            Log.e(TAG, "onProviderDisabled: $provider")
        }
        override fun onProviderEnabled(provider: String) {
            Log.e(TAG, "onProviderEnabled: $provider")
        }
        override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {
            Log.e(TAG, "onStatusChanged: $provider")
        }
    }

    override fun onBind(arg0: Intent): IBinder? {
        return binder
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return Service.START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mLocationManager != null) {
            for (i in mLocationListeners.indices) {
                try {
                    if (ActivityCompat.checkSelfPermission(
                            this,
                            android.Manifest.permission.ACCESS_FINE_LOCATION
                        ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                            this,
                            android.Manifest.permission.ACCESS_COARSE_LOCATION
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        return
                    }
                    mLocationManager!!.removeUpdates(mLocationListeners[i])
                } catch (ex: Exception) {
                    Log.i(TAG, "fail to remove location listener, ignore", ex)
                }
            }
        }
    }

    private fun initializeLocationManager() {
        if (mLocationManager == null) {
            mLocationManager = applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        }
    }

    // marker zoom in zoom out
    private fun bitmapDescriptorFromVector(context: Context, vectorResId: Int,size:Int): BitmapDescriptor {
        val vectorDrawable = ContextCompat.getDrawable(context, vectorResId)
        vectorDrawable!!.setBounds(0, 0, vectorDrawable.intrinsicWidth/size, vectorDrawable.intrinsicHeight/size)

        val bitmap = Bitmap.createBitmap(vectorDrawable.intrinsicWidth/size, vectorDrawable.intrinsicHeight/size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        vectorDrawable.draw(canvas)

        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }
}