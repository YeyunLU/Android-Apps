package com.travker

import android.app.Activity
import android.content.ClipData
import android.content.ClipDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.DragEvent
import android.view.View
import kotlinx.android.synthetic.main.photo_gallery.*
import android.view.ViewGroup
import android.widget.*
import kotlinx.android.synthetic.main.add_notes.*
import org.jetbrains.anko.imageURI


class PhotoGallery : AppCompatActivity() {

    private var pickIMageMultiple = 1
    private var uriList:ArrayList<Uri> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.photo_gallery)

        val diaryName = intent.getStringExtra("diaryName")
        tvDirayName.text = diaryName + " Gallery"

        uriList = intent.getParcelableArrayListExtra("uris")
        Log.d("Photo", uriList.size.toString())
        Log.d("Photo", uriList.toString())
        if(uriList.size > 0)
            setGallery()
    }

    override fun onBackPressed() {
        val intent = Intent(applicationContext, NewDiary::class.java)
        intent.putExtra("uris", uriList)
        setResult(Activity.RESULT_OK, intent)
        Log.d("New Diary", "Put Extra back to diary. " + uriList.toString())
        finish()
    }

    fun addPhotos(view: View){
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(Intent.createChooser(intent,"Select Picture"), pickIMageMultiple)
    }

    private fun setGallery(){
        val galleryAdapter = GalleryAdapter(applicationContext, uriList)
        gvGallery.adapter = galleryAdapter
        gvGallery.verticalSpacing = gvGallery.horizontalSpacing
        val mlp = gvGallery.layoutParams as ViewGroup.MarginLayoutParams
        mlp.setMargins(0, gvGallery.horizontalSpacing, 0, 0)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(requestCode == pickIMageMultiple && resultCode == Activity.RESULT_OK && data != null){
            if(data.data != null){
                uriList.add(data.data)
                Log.d("Photo", "Adding Image:" + uriList.size)
            } else {
                if (data.clipData != null) {
                    val clipData = data.clipData
                    for (i in 0 until clipData.itemCount) {
                        uriList.add(clipData.getItemAt(i).uri)
                        Log.d("Photo", "Adding Image:" + uriList.size)
                    }
                }
            }

            if(uriList.size > 0){
                setGallery()
            }
        } else {
            Toast.makeText(this, "You haven't picked Image", Toast.LENGTH_LONG).show()
        }
    }
}