package com.travker

import android.content.Context
import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class MainAdapter(var context: Context, var diaries: ArrayList<Diary>):BaseAdapter() {

    private class ViewHolder(row:View?){
        var textName : TextView
        var textDate : TextView
        var ivImage  : ImageView

        init{
            this.textName = row?.findViewById(R.id.tvName) as TextView
            this.textDate = row?.findViewById(R.id.tvDate) as TextView
            this.ivImage = row?.findViewById(R.id.ivDiary) as ImageView
        }
    }
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view: View?
        var viewHolder:ViewHolder

        if(convertView == null){
            var layout = LayoutInflater.from(context)
            view = layout.inflate(R.layout.travel_diary,parent, false)
            viewHolder = ViewHolder(view)
            view.tag = viewHolder
        }
        else{
            view = convertView
            viewHolder = view.tag as ViewHolder
        }

        var diary: Diary = getItem(position) as Diary
        viewHolder.textDate.text = diary.date
        viewHolder.textName.text = diary.name
        if(diary.image != null)
            viewHolder.ivImage.setImageURI(Uri.parse(diary.image))
            //viewHolder.ivImage.setImageDrawable(context.getDrawable(R.drawable.map) as Drawable)

        return view as View
    }

    override fun getItem(position: Int): Any {
        return diaries.get(position)
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return diaries.count()
    }
}