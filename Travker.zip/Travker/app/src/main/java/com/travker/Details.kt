package com.travker

class Details(var id: String?="",
              var position: ArrayList<String> = ArrayList(),
              var health: String?="",
              var notes : String?="",
              var gallery: ArrayList<String> = ArrayList()){
}