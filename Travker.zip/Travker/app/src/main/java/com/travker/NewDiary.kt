package com.travker

import java.util.*
import com.travker.MapService
import android.content.*
import android.view.View
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import java.io.File
import kotlin.math.sqrt
import java.io.IOException
import java.io.OutputStream
import android.widget.Toast
import android.widget.TextView
import android.telecom.Call
import android.app.Activity
import java.text.SimpleDateFormat
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Vibrator
import android.provider.MediaStore
import android.app.AlertDialog
import android.widget.EditText
import java.io.FileOutputStream
import kotlin.collections.ArrayList
import android.support.v4.app.ActivityCompat
import android.app.ActivityManager
import android.content.pm.PackageManager
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.new_diary.*
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import kotlinx.android.synthetic.main.editdiary_dialog.*


class NewDiary : AppCompatActivity(), OnMapReadyCallback, GoogleMap.SnapshotReadyCallback,
    GoogleMap.OnMapLoadedCallback {

    val manager = supportFragmentManager

    private lateinit var hcService:HealthCareService
    private lateinit var mapService:MapService
    private lateinit var imgPath:String
    private lateinit var spot_name: String

    private var hcBind: Boolean = false
    private var mapBind: Boolean = false
    private var refreshFlag: Boolean = true
    private var saved: Boolean = false
    private var change: Boolean = false

    private var notesContent: String = ""
    private var galleryPhotos:ArrayList<Uri> = ArrayList()
    private var refreshUI: Thread = Thread(Runnable{ refreshUI() })

    private val hcconnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val hcbinder = service as HealthCareService.LocalBinder
            hcService = hcbinder.getService()
            hcBind = true
        }
        override fun onServiceDisconnected(arg0: ComponentName) {
            hcBind = false
        }
    }

    private val mapconnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val mapbinder = service as MapService.LocalBinder
            mapService = mapbinder.getService()
            mapBind = true

        }
        override fun onServiceDisconnected(arg0: ComponentName) {
            mapBind = false
        }
    }

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
        val polypts = ArrayList<String>()
        lateinit var mMap: GoogleMap
        lateinit var mapFragment: SupportMapFragment
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.new_diary)

        mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        startService(Intent(this, MapService::class.java).also { intent ->
            bindService(intent, mapconnection, Context.BIND_AUTO_CREATE)
        })

        startService(Intent(this, HealthCareService::class.java).also { intent ->
            bindService(intent, hcconnection, Context.BIND_AUTO_CREATE)
        })
        Log.d("main", "health service start")

        refreshUI.start()

        tvDate.text = SimpleDateFormat("MM-dd-yyyy").format(Date())

        ibSave.visibility = View.INVISIBLE
        tvSaveHeader.visibility = View.INVISIBLE

        spot_name = "Spot"
    }

    override fun onBackPressed() {
        if(isServiceRunning(HealthCareService::class.java)){
            exitDialog("Path is recording.\nThe diary will automatically deleted if you click 'ok'")
        }
        else{
            if(!saved)
                exitDialog("You haven't saved the diary.")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                1 -> {
                    Log.d("New Diary", "+++++++++++++++++++++++++++")
                    galleryPhotos = data!!.getParcelableArrayListExtra("uris")
                    Log.d("New Diary", galleryPhotos.toString())
                }
                2 -> {
                    notesContent = data!!.getStringExtra("notesContent")
                    Log.d("New Diary", notesContent)
                }
            }
        }
        else{
            Log.d("New Diary", resultCode.toString())
        }
    }

    override fun onSnapshotReady(bitmap: Bitmap?) {
        try {

            imgPath = bitmapToFile(bitmap)

            var db = DataBase()
            db.connectFirebaseRTDB()

            val diaryTable = db.getDiaryTable()
            var diaryID = diaryTable!!.push().key!!
            val newDiary= Diary(diaryID, tvDate.text.toString(), tvName.text.toString() , imgPath)
            diaryTable.child(diaryID).setValue(newDiary).addOnCompleteListener {
                Toast.makeText(applicationContext, "Diary saved successfully!", Toast.LENGTH_LONG).show()
            }

            var images = ArrayList<String>()
            for(uri in galleryPhotos){
                images.add(uri.toString())
            }

            val detailTable = db.getDetailTable()
            val newDetail = Details(diaryID, polypts, tvHealth.text.toString(), notesContent, images)
            detailTable.child(diaryID).setValue(newDetail).addOnCompleteListener {
                Toast.makeText(applicationContext, "Detail saved successfully!", Toast.LENGTH_LONG).show()
            }

            finish()

        }catch (e: IOException){
            e.printStackTrace()
        }
    }

    override fun onMapLoaded() {
        if (mMap != null) {
            mMap.snapshot(this)
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isRotateGesturesEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true
        mMap.uiSettings.isMyLocationButtonEnabled = true
        setUpMap()
    }

    private fun setUpMap() {
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            return
        }
        mMap.isMyLocationEnabled = true
        mMap.setOnMarkerClickListener(object : GoogleMap.OnMarkerClickListener {
            override fun onMarkerClick(marker:Marker):Boolean{
                if(marker.getTitle().equals("Spot")){
                    editSpotDialog()
                    marker.setTitle(spot_name)
                    if(change){
                        val map_service = MapService()
                        marker.setIcon(map_service.bitmapDescriptorFromVector(this@NewDiary, R.drawable.husky,15))
                    }
                }
                else{
                    marker.showInfoWindow()
                }
                return true
            }
        });
    }

    fun editName(view: View){
        buttonVibe()
        editNameDialog()
    }

    fun openNotes(view: View){
        buttonVibe()
        Log.d("main", "add notes button click.")

        val intent = Intent(this, AddNotes::class.java)
        intent.putExtra("notesContent", notesContent)
        startActivityForResult(intent, 2)
    }

    fun openAlbum(view: View){
        buttonVibe()

        val intent = Intent(this, PhotoGallery::class.java)
        intent.putExtra("diaryName", tvName.text.toString())
        intent.putExtra("uris", galleryPhotos)
        startActivityForResult(intent, 1)
    }

    fun stopRecord(view: View){
        buttonVibe()
        if(isServiceRunning(HealthCareService::class.java)||isServiceRunning(MapService::class.java)){
            stopRecordingWarning()
        }
    }

    fun saveDiary(view: View){
        buttonVibe()

        if (mMap != null) {
            mMap.setOnMapLoadedCallback(this)
        }
    }

    private fun stopServices(){
        unbindService(hcconnection)
        unbindService(mapconnection)
        stopService(Intent(this, HealthCareService::class.java))
        stopService(Intent(this, MapService::class.java))
    }

    private fun isServiceRunning(serviceClass: Class<*>): Boolean {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (service in manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.name == service.service.className) {
                return true
            }
        }
        return false
    }

    private fun refreshUI() {
        while(refreshFlag){
            if(hcBind)
                tvHealth.post({
                    tvHealth.text = "Steps: " + hcService.getSteps().toString()
                })
            Thread.sleep(3000)
        }
    }

    private fun editNameDialog() {
        val builder = AlertDialog.Builder(this)
        val view = layoutInflater.inflate(R.layout.editdiary_dialog, null)

        builder.setTitle("Edit Diary Name")
        builder.setView(view)

        builder.setPositiveButton(android.R.string.ok) { dialog, _ ->
            val name = view.findViewById<EditText>(R.id.etDiaryName)
            if (name.text.toString() != ""){
                tvName.text = name.text.toString()
                dialog.dismiss()
            }
        }

        builder.setNegativeButton(android.R.string.cancel) { dialog, _ ->
            dialog.cancel()
        }
        builder.show()
    }

    private fun editSpotDialog() {
            val builder = AlertDialog.Builder(this)
            val view = layoutInflater.inflate(R.layout.edit_spot, null)

            builder.setTitle("Edit Spot Name")
            builder.setView(view)

            builder.setPositiveButton(android.R.string.ok) { dialog, _ ->
                val name = view.findViewById<EditText>(R.id.etSpotName)
                if (name.text.toString() != ""){
                    spot_name = name.text.toString()
                    dialog.dismiss()
                }
            }

            builder.setNeutralButton("Set Icon") { dialog, _ ->
                change = true
            }

            builder.setNegativeButton(android.R.string.cancel) { dialog, _ ->
                dialog.cancel()
            }
            builder.show()
        }

    private fun exitDialog(s: String){
        val builder = AlertDialog.Builder(this)
        val view = layoutInflater.inflate(R.layout.warning_dialog, null)
        view.findViewById<TextView>(R.id.tvWarning).text = s

        builder.setTitle("Are you sure you want to exit?")
        builder.setView(view)

        builder.setPositiveButton(android.R.string.ok) { dialog, _ ->
            refreshFlag = false
            stopServices()
            polypts.clear()
            finish()
        }

        builder.setNegativeButton(android.R.string.cancel) { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun stopRecordingWarning(){
        val builder = AlertDialog.Builder(this)
        val view = layoutInflater.inflate(R.layout.warning_dialog, null)
        view.findViewById<TextView>(R.id.tvWarning).text = "The diary will stop recording if you click 'ok'"

        builder.setTitle("Are you sure you want to stop recording?")
        builder.setView(view)

        builder.setPositiveButton(android.R.string.ok) { dialog, _ ->
            refreshFlag = false
            stopServices()
            tvHealth.text = tvHealth.text.toString() + " \nDistance: " + getDistance(polypts) + "m"
            ibStop.visibility = View.INVISIBLE
            ibSave.visibility = View.VISIBLE
            tvSaveHeader.visibility = View.VISIBLE
        }

        builder.setNegativeButton(android.R.string.cancel) { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun buttonVibe(){
        val vibratorService = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vibratorService.vibrate(100)
    }

    private fun bitmapToFile(bitmap:Bitmap?): String {
        // Get the context wrapper
        val wrapper = ContextWrapper(applicationContext)

        // Initialize a new file instance to save bitmap object
        var file = wrapper.getDir("Images",Context.MODE_PRIVATE)
        file = File(file,"${UUID.randomUUID()}.jpg")

        try{
            // Compress the bitmap and save in jpg format
            val stream: OutputStream = FileOutputStream(file)
            bitmap!!.compress(Bitmap.CompressFormat.JPEG,100, stream)
            stream.flush()
            stream.close()
        }catch (e: IOException){
            e.printStackTrace()
        }

        return MediaStore.Images.Media.insertImage(contentResolver, bitmap, file.name, file.name).toString()
    }

    private fun getDistance(positions: ArrayList<String>) : String{
        val iterator = positions.iterator()
        var first: Boolean? = true
        var last:LatLng? = null
        var distance = 0.0

        while(iterator.hasNext()) {
            var latlng = iterator.next().split("(")[1].split(",")
            var lat = java.lang.Double.parseDouble(latlng[0])
            var lng = java.lang.Double.parseDouble(latlng[1].split(")")[0])

            if(first!!){
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(lat,lng), 16f))
                first=false
                last = LatLng(lat, lng)
            }
            else{
                distance += sqrt(Math.pow((lat-last!!.latitude), 2.0) + Math.pow((lng-last!!.longitude),2.0)) * 111e3
                last=LatLng(lat,lng)
                Log.d("Distance", distance.toString())
            }
        }

        return "%.2f".format(distance)
    }

}