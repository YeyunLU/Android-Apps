package com.travker

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import com.google.android.gms.tasks.OnFailureListener
import com.google.firebase.storage.UploadTask
import com.google.android.gms.tasks.OnSuccessListener
import java.io.IOException
import java.util.*


class DataBaseTestPage : AppCompatActivity() {

    var database = FirebaseDatabase.getInstance().getReference("Diaries")
    var storageRef = FirebaseStorage.getInstance()!!.reference
    private  val PICK_IMAGE_REQUEST = 1234

    var imgUri: Uri?=null
    var idxDiary: Int?=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.data_base)
        idxDiary = 0
    }
    ///////////////////////////////////////////////////////////////////////////
    fun addChild(view: View)
    {
        NewDiary.polypts.add(LatLng(1.0,3.0).toString())
        NewDiary.polypts.add(LatLng(2.0,6.0).toString())
        NewDiary.polypts.add(LatLng(3.0,9.0).toString())
        //uploadData("2019/6/3","Everything is good today.","Seattle",NewDiary.imgUris,NewDiary.polypts)
    }
    ///////////////////////////////////////////////////////////////////////////
//    private fun uploadData(date:String,content:String,city:String,imgUri:ArrayList<String>,path:ArrayList<String> ){
//        val newCity= Diary(date,content,city,imgUri,path)
//        database.child("diary${idxDiary}").setValue(newCity)
//            .addOnSuccessListener {
//                Toast.makeText(applicationContext,"City saved successfully!",Toast.LENGTH_LONG).show()
//                idxDiary!!.plus(1)
//            }
//            .addOnFailureListener {
//                Toast.makeText(applicationContext,"Failed to save city!",Toast.LENGTH_LONG).show()
//            }
//    }

    fun getChild(view:View){
        retrieveChild("diary0");
    }

    fun retrieveChild(name:String){
        database.child(name).addValueEventListener(object:ValueEventListener{
            override fun onDataChange(data: DataSnapshot) {
                val mCity = data.getValue(Diary::class.java)
                val text = "City: ${mCity}"
                //val imgs = mCity!!.imgUris
                //Toast.makeText(applicationContext, imgs.toString(), Toast.LENGTH_SHORT).show()
            }
            override fun onCancelled(databaseError: DatabaseError) {

                Log.e("Get Data from Firebase", "Can not retrive data!")
            }
        })
    }

    fun chooseImg(view: View){
        val intent = Intent()
        intent.type="image/*"
        intent.action=Intent.ACTION_GET_CONTENT
        startActivityForResult(Intent.createChooser(intent,"Select Picture"),PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode==PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK
            && data!=null && data.data!=null){
            imgUri= data.data
            //NewDiary.imgUris.add(data.data.toString())
            try{
                val bitmap = MediaStore.Images.Media.getBitmap(contentResolver,imgUri)
            }catch (e:IOException){
                e.printStackTrace()
            }
        }
    }

    fun uploadImg(view: View) {
        if (imgUri != null) {
            val progressDialog = ProgressDialog(this)
            progressDialog.setTitle("Uploading...")
            progressDialog.show()
            var fileRef = storageRef!!.child("images/" + UUID.randomUUID().toString()) // unique ID
                fileRef.putFile(imgUri!!)
                .addOnSuccessListener(OnSuccessListener<UploadTask.TaskSnapshot> { taskSnapshot ->
                progressDialog.dismiss()
                Toast.makeText(applicationContext,"Uploaded successfully!",Toast.LENGTH_LONG).show()
            })
                .addOnFailureListener(OnFailureListener {
                progressDialog.dismiss()
                Toast.makeText(applicationContext,"Failed to save image!",Toast.LENGTH_LONG).show()
            })
                .addOnProgressListener{taskSnapShot->
                val progress = 100.0 * taskSnapShot.bytesTransferred/taskSnapShot.totalByteCount
                progressDialog.setMessage("Uploaded "+progress.toInt()+"%...")
    }

        } else {
            Toast.makeText(this, "No such files", Toast.LENGTH_LONG).show()
        }
    }

}