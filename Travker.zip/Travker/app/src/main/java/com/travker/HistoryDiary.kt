package com.travker

import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.android.synthetic.main.history_diary.*
import java.lang.Double.parseDouble
import java.lang.Math.pow
import kotlin.math.sqrt
import android.widget.LinearLayout
import android.view.View.MeasureSpec
import android.widget.ScrollView


class HistoryDiary: AppCompatActivity(), OnMapReadyCallback {
    private lateinit var mMap: GoogleMap
    private lateinit var positions:ArrayList<String>
    private val LOCATION_PERMISSION_REQUEST_CODE = 1

    private val textParam = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT,
        1.0f
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.history_diary)

        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        tvName.text = intent.getStringExtra("name")
        tvDate.text = intent.getStringExtra("date")

        var db = DataBase()
        db.connectFirebaseRTDB()
        db.getDetailTable().child(intent.getStringExtra("id")).addValueEventListener(object: ValueEventListener {
            override fun onDataChange(data: DataSnapshot) {
                val details = data.getValue(Details::class.java)!!

                tvHealth.text = details.health
                tvHealth.layoutParams = textParam

                if(details.notes == "") {
                    tvNoteHeader.visibility = View.INVISIBLE
                    tvNotes.visibility = View.INVISIBLE
                }
                else {
                    tvNotes.text = details.notes

                    tvNotes.layoutParams = textParam
                }

                if(details.gallery != null) {
                    if (details.gallery.size == 0) {
                        tvGalleryHeader.visibility = View.INVISIBLE
                        Log.d("History", "No photos")
                    } else {
                        Log.d("History", "photo size: " + details.gallery.size)
                        setupGallery(details.gallery)
                    }
                }
                positions = details.position
                if (positions!=null){
                    if (positions.size == 0) {
                        tvGalleryHeader.visibility = View.INVISIBLE
                        Log.d("History", "No recorded path")
                    } else {
                        setupGoogleMap(positions)
                    }
                }
            }
            override fun onCancelled(databaseError: DatabaseError) {
                Log.e("Get Data from Firebase", "Can not retrive data!")
            }
        })
        svView.smoothScrollTo(0,0)
    }

    private fun setupGallery(gallery : ArrayList<String>){
        val uriList = ArrayList<Uri>()
        for (s in gallery)
            uriList.add(Uri.parse(s))

        val galleryAdapter = GalleryAdapter(applicationContext, uriList)
        gvGallery.adapter = galleryAdapter
        gvGallery.verticalSpacing = gvGallery.horizontalSpacing
        val mlp = gvGallery.layoutParams as ViewGroup.MarginLayoutParams
        mlp.setMargins(0, gvGallery.horizontalSpacing, 0, 0)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isRotateGesturesEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true
        mMap.uiSettings.isMyLocationButtonEnabled = true
        setUpMap()
    }

    private fun setUpMap() {
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            return
        }
        mMap.isMyLocationEnabled = true
    }

    private fun setupGoogleMap(positions : ArrayList<String>){
        val options = PolylineOptions()
        options.color(Color.RED).width(10f)

        val iterator = positions.iterator()
        var first: Boolean? = true
        while(iterator.hasNext()) {

            var latlng = iterator.next().split("(")[1].split(",")
            var lat = parseDouble(latlng[0])
            var lng = parseDouble(latlng[1].split(")")[0])
            options.add(LatLng(lat,lng))
            if(first!!){
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(lat,lng), 16f))
                first=false
            }
        }
        mMap!!.addPolyline(options)
    }

}
