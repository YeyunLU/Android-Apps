Travker - "Travel Tracker" - An app for final team project with Ernie and Cindy.
This app is for recording travel log anytime and anywhere. It includes functions like path recording, photo gallery, voice
to text and step count. Also, we use firebase as our database to store all the data, so that people who use this app can 
share their interesting travel experience with others.
Demo: https://youtu.be/rvEOGNc1cqc